var searchData=
[
  ['margin',['Margin',['../structwkhtmltopdf_1_1settings_1_1Margin.html',1,'wkhtmltopdf::settings']]],
  ['margin',['margin',['../structwkhtmltopdf_1_1settings_1_1PdfGlobal.html#a5134abc2cf21870b455416d5efc466f6',1,'wkhtmltopdf::settings::PdfGlobal']]]
];
